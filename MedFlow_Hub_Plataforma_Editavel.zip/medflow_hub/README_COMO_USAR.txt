# MedFlow Hub - Protótipo Editável

Este é um protótipo inicial da plataforma para agência de marketing médico.

## Como usar

1. Descompacte a pasta.
2. Abra o arquivo `index.html` no Google Chrome.
3. No menu lateral, escolha o perfil:
   - CEO / Diretor
   - Atendimento
   - Rede de Conteúdo
   - Redator
   - Designer
   - Editor
   - Cliente

## O que já funciona

- Dashboard por perfil
- Controle de acesso simulado por cargo
- Clientes atribuídos por atendimento, redator, designer e editor
- Agenda estilo Google Agenda para equipe
- Portal da cliente com datas disponíveis
- Cliente pode marcar gravação/reunião
- Pautas e roteiros estilo Docs
- Artes em Kanban estilo Trello
- Cliente pode comentar e aprovar artes
- Vídeos e brutos estilo Drive
- Cliente pode comentar e aprovar vídeos
- Notificações simuladas entre setores
- Dados editáveis salvos no navegador via localStorage

## Importante

Este protótipo roda localmente no navegador. 
Para virar uma plataforma real online, é preciso:
- hospedagem
- banco de dados real
- login com senha
- armazenamento de arquivos
- envio real de e-mails/notificações
- permissões seguras

## Sugestão de evolução

Versão rápida:
- Softr + Airtable + Google Drive + Google Calendar + Make

Versão profissional:
- React + Supabase + Storage + Auth + Notificações por e-mail
